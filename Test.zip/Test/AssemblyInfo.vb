'' Assembly App_Web_juhheiwv, Version 0.0.0.0

<Assembly: System.Reflection.AssemblyVersion("0.0.0.0")>
<Assembly: System.CodeDom.Compiler.GeneratedCode("ASP.NET", "2.0.50727.210")>
<Assembly: System.Runtime.CompilerServices.CompilationRelaxations(8)>
<Assembly: System.Runtime.CompilerServices.RuntimeCompatibility(WrapNonExceptionThrows:=True)>

